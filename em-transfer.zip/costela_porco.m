x = [ 2.6147    6.2832    3.0095    0.8353 3.09 261.96 2.28];
clear tempo_total;
clear custo_total;
dt = -365:365;
for i = 1:10
    x = x + [ 0 0 0 0 0 30*i 0];
funcao_custo;
tempo_total(i) = x(5) + x(6) + x(7)
custo_total(i) = value;
end
