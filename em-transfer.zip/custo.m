function valor = custo(x_)
    %METHOD1 Summary of this method goes here
    %   Detailed explanation goes here
    x = x_;
    funcao_custo;
    valor = value;
end

